using System;
using TechTalk.SpecFlow;

namespace Mc2.CrudTest.AcceptanceTests.Hooks
{
    [Binding]
    public class Hooks
    {
    }
}