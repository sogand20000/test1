using System;

namespace Mc2.CrudTest.AcceptanceTests.Drivers
{
    public class Driver
    {
    }
}